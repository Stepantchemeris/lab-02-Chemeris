package kit.mdk0103.chemeris.lab02;

public class Converter {
    public enum Unit {
        Дюймы,
        Сантиметры,
        Футы,
        Ярды,
        Метры,
        Мили,
        Километры;
        // Конвертирование текста в одну из констант
        public static Unit fromString(String text) {
            if (text != null) {
                for (Unit unit : Unit.values()) {
                    if (text.equalsIgnoreCase(unit.toString())) {
                        return unit;
                    }
                }
            }
            throw new IllegalArgumentException("Нет значения для " + text);
        }
    }
    private final double multiplier;

    public Converter(Unit from, Unit to) {
        double constant = 1;
        // Установка множителя, если fromUnit = toUnit, тогда он равен одному
        switch (from) {
            case Дюймы:
                if (to == Unit.Сантиметры) {
                    constant = 2.54;
                } else if (to == Unit.Футы) {
                    constant = 0.0833333;
                } else if (to == Unit.Ярды) {
                    constant = 0.0277778;
                } else if (to == Unit.Метры) {
                    constant = 0.0254;
                } else if (to == Unit.Мили) {
                    constant = 1.5783e-5;
                } else if (to == Unit.Километры) {
                    constant = 2.54e-5;
                }
                break;
            case Сантиметры:
                if (to == Unit.Дюймы) {
                    constant = 0.393701;
                } else if (to == Unit.Футы) {
                    constant = 0.0328084;
                } else if (to == Unit.Ярды) {
                    constant = 0.0109361;
                } else if (to == Unit.Метры) {
                    constant = 0.01;
                } else if (to == Unit.Мили) {
                    constant = 6.2137e-6;
                } else if (to == Unit.Километры) {
                    constant = 1e-5;
                }
                break;
            case Футы:
                if (to == Unit.Дюймы) {
                    constant = 12;
                } else if (to == Unit.Сантиметры) {
                    constant = 30.48;
                } else if (to == Unit.Ярды) {
                    constant = 0.333333;
                } else if (to == Unit.Метры) {
                    constant = 0.3048;
                } else if (to == Unit.Мили) {
                    constant = 0.000189394;
                } else if (to == Unit.Километры) {
                    constant = 0.0003048;
                }
                break;
            case Ярды:
                if (to == Unit.Дюймы) {
                    constant = 36;
                } else if (to == Unit.Сантиметры) {
                    constant = 91.44;
                } else if (to == Unit.Футы) {
                    constant = 3;
                } else if (to == Unit.Метры) {
                    constant = 0.9144;
                } else if (to == Unit.Мили) {
                    constant = 0.000568182;
                } else if (to == Unit.Километры) {
                    constant = 0.0009144;
                }
                break;
            case Метры:
                if (to == Unit.Дюймы) {
                    constant = 39.3701;
                } else if (to == Unit.Сантиметры) {
                    constant = 100;
                } else if (to == Unit.Футы) {
                    constant = 3.28084;
                } else if (to == Unit.Ярды) {
                    constant = 1.09361;
                } else if (to == Unit.Мили) {
                    constant = 0.000621371;
                } else if (to == Unit.Километры) {
                    constant = 0.001;
                }
                break;
            case Мили:
                if (to == Unit.Дюймы) {
                    constant = 63360;
                } else if (to == Unit.Сантиметры) {
                    constant = 160934;
                } else if (to == Unit.Футы) {
                    constant = 5280;
                } else if (to == Unit.Ярды) {
                    constant = 1760;
                } else if (to == Unit.Метры) {
                    constant = 1609.34;
                } else if (to == Unit.Километры) {
                    constant = 1.60934;
                }
                break;
            case Километры:
                if (to == Unit.Дюймы) {
                    constant = 39370.1;
                } else if (to == Unit.Сантиметры) {
                    constant = 100000;
                } else if (to == Unit.Футы) {
                    constant = 3280.84;
                } else if (to == Unit.Ярды) {
                    constant = 1093.61;
                } else if (to == Unit.Метры) {
                    constant = 1000;
                } else if (to == Unit.Мили) {
                    constant = 0.621371;
                }
                break;
        }

        multiplier = constant;
    }

    // Конвертация ячейки
    public double convert(double input) {
        return input * multiplier;
    }
}
